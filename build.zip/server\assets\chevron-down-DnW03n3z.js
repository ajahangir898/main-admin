import{c as o}from"./createLucideIcon-Bok4r-Pq.js";const n=o("ChevronDown",[["path",{d:"m6 9 6 6 6-6",key:"qrunsl"}]]);export{n as C};
