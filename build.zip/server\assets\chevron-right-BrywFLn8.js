import{c as t}from"./createLucideIcon-Bok4r-Pq.js";const h=t("ChevronRight",[["path",{d:"m9 18 6-6-6-6",key:"mthhwq"}]]);export{h as C};
