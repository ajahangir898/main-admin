import{c as e}from"./createLucideIcon-Bok4r-Pq.js";const o=e("Check",[["polyline",{points:"20 6 9 17 4 12",key:"10jjfj"}]]);export{o as C};
