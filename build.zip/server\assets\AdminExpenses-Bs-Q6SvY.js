import{jsxs as a,jsx as e}from"react/jsx-runtime";import{useState as i,useMemo as P,useEffect as W}from"react";import{E as I}from"./ExpenseService-B5SHoysH.js";import{C as A}from"./CategoryService-CQRykZO0.js";import{n as Z}from"./imageUrlHelper-fcb-rV93.js";import{S as ee}from"./search-Cnea1i1C.js";import{P as M}from"./plus-B95QM_A7.js";import{P as te}from"./printer-vASCsjgz.js";import{F as ae}from"./filter-D2BvdJ5c.js";import{C as le}from"./chevron-left-Bxvk9mPa.js";import{C as se}from"./chevron-right-BrywFLn8.js";import{I as O}from"./image--uu5Kml3.js";import{P as B}from"./pen-DO-yAWDV.js";import{T as R}from"./trash-2-Dn1WtL_Y.js";import{X as de}from"./x-CaYvzBUf.js";import"./createLucideIcon-Bok4r-Pq.js";const Ce=()=>{const[x,G]=i(""),[h,q]=i("All"),[p,Q]=i(""),[o]=i({}),[C,g]=i([]),[T,D]=i([]),[ie,$]=i(!1),[z,F]=i(null),[u,j]=i(1),f=10,[V,b]=i(!1),[l,r]=i({status:"Draft"}),[m,v]=i(null),[X,w]=i(!1),[k,N]=i(""),[y,S]=i(null),n=P(()=>C.filter(t=>(h==="All"||t.status===h)&&(!p||t.category===p)&&(!x||t.name.toLowerCase().includes(x.toLowerCase()))&&(!o.from||new Date(t.date)>=new Date(o.from))&&(!o.to||new Date(t.date)<=new Date(o.to))),[C,h,p,x,o]),U=P(()=>{const t=(u-1)*f;return n.slice(t,t+f)},[n,u]),E=P(()=>n.reduce((t,d)=>t+d.amount,0),[n]);W(()=>{(async()=>{try{$(!0),F(null);const[d,s]=await Promise.all([I.list({query:x,status:h==="All"?void 0:h,category:p||void 0,from:o.from,to:o.to,page:u,pageSize:f}),A.list()]);g(d.items),D(s.items)}catch(d){F(d?.message||"Failed to load expenses")}finally{$(!1)}})()},[x,h,p,o.from,o.to,u,f]);const Y=async()=>{if(!l.name||!l.category||!l.amount||!l.date)return;const t={name:l.name,category:l.category,amount:Number(l.amount),date:l.date,status:l.status||"Draft",note:l.note,imageUrl:l.imageUrl};try{if(m){const d=await I.update(m,t);g(s=>s.map(c=>c.id===m?{...d,id:d.id||m}:c))}else{const d=await I.create(t);g(s=>[{...d,id:d.id||Math.random().toString(36).slice(2)},...s])}b(!1),r({status:"Draft"}),v(null)}catch{if(m)g(s=>s.map(c=>c.id===m?l:c));else{const s={id:Math.random().toString(36).slice(2),...t};g(c=>[s,...c])}b(!1),r({status:"Draft"}),v(null)}},_=t=>{r(t),v(t.id),b(!0)},H=async()=>{if(k.trim())try{if(y){const t=await A.update(y,{name:k});D(d=>d.map(s=>s.id===y?t:s))}else{const t=await A.create({name:k});D(d=>[...d,t])}N(""),S(null),w(!1)}catch{alert("Failed to save category")}},J=async t=>{if(window.confirm("Delete this category?"))try{await A.remove(t),D(d=>d.filter(s=>s.id!==t))}catch{alert("Failed to delete category")}},K=()=>{const t=window.open("","_blank");if(!t)return;const d=`
      <!DOCTYPE html>
      <html>
      <head>
        <title>Expense Invoice</title>
        <style>
          * { margin: 0; padding: 0; box-sizing: border-box; }
          body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; color: #333; }
          .container { max-width: 900px; margin: 0 auto; padding: 40px; }
          header { text-align: center; margin-bottom: 40px; border-bottom: 3px solid #0f766e; padding-bottom: 20px; }
          .logo { font-size: 32px; font-weight: bold; color: #0f766e; margin-bottom: 10px; }
          .subtitle { color: #888; font-size: 14px; }
          .info-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 20px; margin-bottom: 30px; }
          .info-box { padding: 15px; background: #f5f5f5; border-radius: 8px; }
          .info-label { font-weight: bold; color: #0f766e; font-size: 12px; text-transform: uppercase; }
          .info-value { margin-top: 5px; font-size: 14px; }
          table { width: 100%; border-collapse: collapse; margin: 30px 0; }
          thead { background: #0f766e; color: white; }
          th { padding: 12px; text-align: left; font-weight: 600; }
          td { padding: 12px; border-bottom: 1px solid #eee; }
          tr:hover { background: #fafafa; }
          .text-right { text-align: right; }
          .amount { font-weight: bold; color: #0f766e; }
          .total-row { font-weight: bold; font-size: 16px; background: #f0f0f0; }
          .summary { display: grid; grid-template-columns: repeat(3, 1fr); gap: 20px; margin: 30px 0; }
          .summary-card { padding: 20px; background: #0f766e; color: white; border-radius: 8px; text-align: center; }
          .summary-label { font-size: 12px; opacity: 0.9; }
          .summary-value { font-size: 24px; font-weight: bold; margin-top: 10px; }
          footer { margin-top: 40px; padding-top: 20px; border-top: 1px solid #eee; text-align: center; color: #888; font-size: 12px; }
          @media print { body { margin: 0; padding: 0; } .container { padding: 20px; } }
        </style>
      </head>
      <body>
        <div class="container">
          <header>
            <div class="logo">OP-BD.COM</div>
            <div class="subtitle">Professional Expense Report</div>
          </header>

          <div class="info-grid">
            <div class="info-box">
              <div class="info-label">Report Date</div>
              <div class="info-value">${new Date().toLocaleDateString("en-US",{year:"numeric",month:"long",day:"numeric"})}</div>
            </div>
            <div class="info-box">
              <div class="info-label">Total Expenses</div>
              <div class="info-value amount">BDT ${E.toFixed(2)}</div>
            </div>
          </div>

          <div class="summary">
            <div class="summary-card">
              <div class="summary-label">Total Amount</div>
              <div class="summary-value">BDT ${E.toFixed(2)}</div>
            </div>
            <div class="summary-card">
              <div class="summary-label">Categories</div>
              <div class="summary-value">${new Set(n.map(s=>s.category)).size}</div>
            </div>
            <div class="summary-card">
              <div class="summary-label">Transactions</div>
              <div class="summary-value">${n.length}</div>
            </div>
          </div>

          <table>
            <thead>
              <tr>
                <th>Date</th>
                <th>Name</th>
                <th>Category</th>
                <th>Status</th>
                <th class="text-right">Amount</th>
              </tr>
            </thead>
            <tbody>
              ${n.map(s=>`
                <tr>
                  <td>${new Date(s.date).toLocaleDateString()}</td>
                  <td>${s.name}</td>
                  <td>${s.category}</td>
                  <td>${s.status}</td>
                  <td class="text-right amount">BDT ${s.amount.toFixed(2)}</td>
                </tr>
              `).join("")}
              <tr class="total-row">
                <td colspan="4" style="text-align: right;">TOTAL</td>
                <td class="text-right" style="color: #0f766e;">BDT ${E.toFixed(2)}</td>
              </tr>
            </tbody>
          </table>

          <footer>
            <p>This is an automatically generated expense report. Generated on ${new Date().toLocaleString()}</p>
          </footer>
        </div>
      </body>
      </html>
    `;t.document?.open(),t.document?.write(d),t.document?.close(),setTimeout(()=>t.print(),500)},L=Math.max(1,Math.ceil(n.length/f));return a("div",{className:"space-y-4 h-full overflow-auto",children:[a("div",{className:"bg-[#0a0e12] rounded-lg p-4",children:[a("div",{className:"flex flex-col md:flex-row md:items-center md:justify-between gap-3",children:[a("div",{children:[e("h2",{className:"text-xl md:text-2xl font-bold text-white",children:"Expense Summary"}),e("p",{className:"text-sm text-slate-400",children:"Total expenses overview for the selected period."})]}),a("div",{className:"flex items-center gap-2",children:[a("div",{className:"flex items-center bg-white/5 rounded-lg px-3 py-2",children:[e(ee,{className:"w-4 h-4 text-slate-300"}),e("input",{value:x,onChange:t=>G(t.target.value),placeholder:"Search",className:"bg-transparent text-slate-200 text-sm outline-none ml-2"})]}),a("button",{onClick:()=>b(!0),className:"inline-flex items-center gap-2 bg-emerald-600 hover:bg-emerald-500 text-white px-3 py-2 rounded-lg text-sm font-semibold",children:[e(M,{className:"w-4 h-4"}),"Add Expense"]})]})]}),a("div",{className:"grid grid-cols-1 md:grid-cols-4 gap-3 mt-3",children:[a("div",{className:"col-span-1 md:col-span-2 bg-emerald-600/20 rounded-lg p-3",children:[a("div",{className:"text-2xl md:text-3xl font-black text-emerald-300",children:["BDT",E.toFixed(2)]}),a("div",{className:"text-xs text-slate-300",children:["Total Expense • ",n.length," transactions"]})]}),a("div",{className:"bg-white/5 rounded-lg p-3",children:[e("div",{className:"text-slate-300 text-xs",children:"Summary"}),a("div",{className:"mt-2 grid grid-cols-3 gap-2 text-center",children:[a("div",{children:[e("div",{className:"text-lg font-bold text-white",children:new Set(C.map(t=>t.category)).size}),e("div",{className:"text-[11px] text-slate-400",children:"Categories"})]}),a("div",{children:[e("div",{className:"text-lg font-bold text-white",children:C.length}),e("div",{className:"text-[11px] text-slate-400",children:"Total Transactions"})]}),a("div",{children:[e("div",{className:"text-lg font-bold text-white",children:n.length}),e("div",{className:"text-[11px] text-slate-400",children:"Filtered"})]})]})]}),a("div",{className:"bg-white/5 rounded-lg p-3",children:[e("div",{className:"text-slate-300 text-xs mb-2",children:"Actions"}),a("div",{className:"flex items-center gap-2",children:[a("button",{onClick:()=>{N(""),S(null),w(!0)},className:"inline-flex items-center gap-2 bg-white/10 hover:bg-white/20 text-white px-3 py-2 rounded-lg text-xs font-semibold",children:[e(M,{className:"w-4 h-4"})," Category"]}),a("button",{onClick:K,className:"inline-flex items-center gap-2 bg-white/10 hover:bg-white/20 text-white px-3 py-2 rounded-lg text-xs font-semibold",children:[e(te,{className:"w-4 h-4"})," Print"]})]}),a("div",{className:"flex items-center gap-2 mt-2",children:[e(ae,{className:"w-4 h-4 text-slate-300"}),a("select",{value:p,onChange:t=>Q(t.target.value),className:"bg-transparent text-slate-200 text-xs rounded-md px-2 py-1",children:[e("option",{value:"",children:"Filter by Category"}),T.map(t=>e("option",{value:t.name,children:t.name},t.id))]})]})]})]})]}),a("div",{className:"bg-[#0a0e12] rounded-lg p-4",children:[a("div",{className:"flex items-center justify-between",children:[e("div",{className:"flex items-center gap-3 text-sm",children:["All","Published","Draft","Trash"].map(t=>a("button",{onClick:()=>q(t),className:`font-semibold ${h===t?"text-emerald-300":"text-slate-400"} hover:text-white`,children:[t,t==="All"?` (${n.length})`:""]},t))}),a("div",{className:"flex items-center gap-2",children:[e("button",{onClick:()=>{N(""),S(null),w(!0)},className:"text-xs bg-white/10 hover:bg-white/20 text-white px-2 py-1 rounded-md",children:"+ Add Category"}),a("div",{className:"flex items-center gap-2 text-xs text-white/80",children:[e("button",{disabled:!0,className:"px-2 py-1 bg-white/10 rounded-md",children:"1"}),a("span",{children:["of ",L]}),e("button",{onClick:()=>j(Math.max(1,u-1)),className:"px-2 py-1 bg-white/10 rounded-md",children:e(le,{className:"w-3 h-3"})}),e("button",{onClick:()=>j(Math.min(L,u+1)),className:"px-2 py-1 bg-white/10 rounded-md",children:e(se,{className:"w-3 h-3"})})]})]})]}),e("div",{className:"mt-3 overflow-x-auto",children:z?e("div",{className:"py-10 text-center text-red-400",children:z}):U.length===0?e("div",{className:"py-16 text-center",children:a("div",{className:"flex flex-col items-center text-slate-400",children:[e(O,{className:"w-10 h-10 mb-2"}),e("div",{className:"font-semibold",children:"No Data Found!"}),e("div",{className:"text-xs",children:"Please add some data to show here."})]})}):a("table",{className:"min-w-full text-sm",children:[e("thead",{children:a("tr",{className:"text-left text-slate-300 border-b border-white/10",children:[e("th",{className:"p-2",children:e("input",{type:"checkbox",disabled:!0})}),e("th",{className:"p-2",children:"Image"}),e("th",{className:"p-2",children:"Name"}),e("th",{className:"p-2",children:"Category"}),e("th",{className:"p-2",children:"Amount"}),e("th",{className:"p-2",children:"Date"}),e("th",{className:"p-2",children:"Status"}),e("th",{className:"p-2",children:"Actions"})]})}),e("tbody",{children:U.map((t,d)=>a("tr",{className:"border-b border-white/5",children:[e("td",{className:"p-2",children:e("input",{type:"checkbox"})}),e("td",{className:"p-2",children:t.imageUrl?e("img",{src:Z(t.imageUrl),alt:"receipt",className:"w-10 h-10 rounded object-cover"}):e("div",{className:"w-10 h-10 bg-white/5 rounded flex items-center justify-center",children:e(O,{className:"w-5 h-5 text-slate-400"})})}),e("td",{className:"p-2 text-white",children:t.name}),e("td",{className:"p-2 text-slate-300",children:t.category}),a("td",{className:"p-2 text-emerald-300 font-semibold",children:["BDT",t.amount.toFixed(2)]}),e("td",{className:"p-2 text-slate-300",children:new Date(t.date).toLocaleDateString()}),e("td",{className:"p-2",children:e("span",{className:`px-2 py-1 rounded-full text-xs font-semibold ${t.status==="Published"?"bg-emerald-600/20 text-emerald-300":"bg-white/10 text-slate-300"}`,children:t.status})}),e("td",{className:"p-2",children:a("div",{className:"flex items-center gap-2 text-slate-300",children:[e("button",{className:"p-1 hover:text-white",onClick:()=>_(t),children:e(B,{className:"w-4 h-4"})}),e("button",{className:"p-1 hover:text-red-400",onClick:()=>g(s=>s.filter(c=>c.id!==t.id)),children:e(R,{className:"w-4 h-4"})})]})})]},t.id||`expense-${d}`))})]})})]}),V&&e("div",{className:"fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-50",children:a("div",{className:"bg-[#0a0e12] rounded-lg p-6 w-full max-w-lg",children:[a("div",{className:"flex items-center justify-between mb-4",children:[e("h3",{className:"text-white font-bold",children:m?"Edit Expense":"Add Expense"}),e("button",{onClick:()=>{b(!1),r({status:"Draft"}),v(null)},className:"text-slate-400 hover:text-white",children:"✕"})]}),a("div",{className:"space-y-3",children:[a("div",{children:[e("label",{className:"text-xs text-slate-400",children:"Expense Name"}),e("input",{className:"mt-1 w-full bg-white/5 border border-white/10 rounded-md px-3 py-2 text-sm text-white",value:l.name||"",onChange:t=>r({...l,name:t.target.value})})]}),a("div",{children:[e("label",{className:"text-xs text-slate-400",children:"Category"}),a("select",{className:"mt-1 w-full bg-white/5 border border-white/10 rounded-md px-3 py-2 text-sm text-white",value:l.category||"",onChange:t=>r({...l,category:t.target.value}),children:[e("option",{value:"",children:"Select Category"}),T.map(t=>e("option",{value:t.name,children:t.name},t.id))]})]}),a("div",{className:"grid grid-cols-2 gap-3",children:[a("div",{children:[e("label",{className:"text-xs text-slate-400",children:"Amount"}),e("input",{type:"number",className:"mt-1 w-full bg-white/5 border border-white/10 rounded-md px-3 py-2 text-sm text-white",value:l.amount||"",onChange:t=>r({...l,amount:Number(t.target.value)})})]}),a("div",{children:[e("label",{className:"text-xs text-slate-400",children:"Date"}),e("input",{type:"date",className:"mt-1 w-full bg-white/5 border border-white/10 rounded-md px-3 py-2 text-sm text-white",value:l.date||"",onChange:t=>r({...l,date:t.target.value})})]})]}),a("div",{children:[e("label",{className:"text-xs text-slate-400",children:"Image Upload (URL)"}),e("input",{className:"mt-1 w-full bg-white/5 border border-white/10 rounded-md px-3 py-2 text-sm text-white",value:l.imageUrl||"",onChange:t=>r({...l,imageUrl:t.target.value}),placeholder:"https://..."})]}),a("div",{children:[e("label",{className:"text-xs text-slate-400",children:"Status"}),a("select",{className:"mt-1 w-full bg-white/5 border border-white/10 rounded-md px-3 py-2 text-sm text-white",value:l.status||"Draft",onChange:t=>r({...l,status:t.target.value}),children:[e("option",{children:"Draft"}),e("option",{children:"Published"})]})]}),a("div",{children:[e("label",{className:"text-xs text-slate-400",children:"Note"}),e("textarea",{className:"mt-1 w-full bg-white/5 border border-white/10 rounded-md px-3 py-2 text-sm text-white",value:l.note||"",onChange:t=>r({...l,note:t.target.value})})]}),a("div",{className:"flex items-center justify-end gap-2 pt-2",children:[e("button",{onClick:()=>{b(!1),r({status:"Draft"}),v(null)},className:"px-3 py-2 text-sm bg-white/10 hover:bg-white/20 text-white rounded-md",children:"Cancel"}),e("button",{onClick:Y,className:"px-3 py-2 text-sm bg-emerald-600 hover:bg-emerald-500 text-white rounded-md font-semibold",children:m?"Update Expense":"Save Expense"})]})]})]})}),X&&e("div",{className:"fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-50",children:a("div",{className:"bg-[#0a0e12] rounded-lg p-6 w-full max-w-lg",children:[a("div",{className:"flex items-center justify-between mb-4",children:[e("h3",{className:"text-white font-bold",children:y?"Edit Category":"Add Category"}),e("button",{onClick:()=>w(!1),className:"text-slate-400 hover:text-white",children:e(de,{className:"w-5 h-5"})})]}),a("div",{className:"space-y-4 mb-4",children:[e("input",{type:"text",placeholder:"Category name",className:"w-full bg-white/5 border border-white/10 rounded-md px-3 py-2 text-sm text-white",value:k,onChange:t=>N(t.target.value)}),a("div",{className:"flex gap-2",children:[e("button",{onClick:H,className:"flex-1 px-3 py-2 text-sm bg-emerald-600 hover:bg-emerald-500 text-white rounded-md font-semibold",children:y?"Update":"Add"}),e("button",{onClick:()=>w(!1),className:"flex-1 px-3 py-2 text-sm bg-white/10 hover:bg-white/20 text-white rounded-md",children:"Cancel"})]})]}),a("div",{className:"border-t border-white/10 pt-4",children:[e("h4",{className:"text-white text-sm font-semibold mb-3",children:"All Categories"}),e("div",{className:"space-y-2 max-h-64 overflow-y-auto",children:T.map(t=>a("div",{className:"flex items-center justify-between bg-white/5 p-2 rounded-md",children:[e("span",{className:"text-sm text-white",children:t.name}),a("div",{className:"flex gap-2",children:[e("button",{onClick:()=>{N(t.name),S(t.id)},className:"p-1 text-emerald-300 hover:text-emerald-200",children:e(B,{className:"w-3 h-3"})}),e("button",{onClick:()=>J(t.id),className:"p-1 text-red-300 hover:text-red-200",children:e(R,{className:"w-3 h-3"})})]})]},t.id))})]})]})})]})};export{Ce as default};
