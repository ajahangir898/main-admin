const e=(r,t="—")=>typeof r=="number"&&Number.isFinite(r)?r.toLocaleString():t;export{e as f};
