import{c as t}from"./createLucideIcon-Bok4r-Pq.js";const o=t("ArrowUpRight",[["path",{d:"M7 7h10v10",key:"1tivn9"}],["path",{d:"M7 17 17 7",key:"1vkiza"}]]);export{o as A};
