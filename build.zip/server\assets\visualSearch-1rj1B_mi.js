const c={VITE_GEMINI_API_KEY:"AIzaSyCLopnqlWpdGBMPEZs_EJJYNuVWJi_xQs0"};let o=null;const d=async()=>(o||(o=await import("@google/genai")),o),l=`You are a retail product expert assisting visual product search. Analyze the provided product photo and respond ONLY with valid JSON matching this TypeScript interface:
{
  "productName": string;
  "brand": string | null;
  "estimatedPrice": string | null;
  "category": string | null;
  "description": string | null;
}
Guidelines:
- productName should be concise and human readable.
- brand should be null if unknown.
- estimatedPrice should be a single currency-formatted string or null.
- category should be null if you cannot infer it confidently.
- description should be a short marketing style summary (max 45 words).
- Never include extra keys, markdown, or commentary.`,m=()=>{const e=typeof import.meta<"u"?c??{}:{},t=typeof process<"u"?process.env??{}:{};return(e.VITE_GEMINI_API_KEY||e.VITE_GOOGLE_AI_API_KEY||t.VITE_GEMINI_API_KEY||t.VITE_GOOGLE_AI_API_KEY||t.GEMINI_API_KEY||t.GOOGLE_AI_API_KEY||"")?.trim()||""},p=async e=>{if(!e)throw new Error("Gemini API key is missing. Add VITE_GEMINI_API_KEY (or VITE_GOOGLE_AI_API_KEY) to your environment configuration.");const{GoogleGenAI:t}=await d();return new t({apiKey:e,apiVersion:"v1alpha"})},u=e=>{if(!e)throw new Error("No image data provided for visual search.");const[,t]=e.split(",");return t||e},g=e=>({productName:typeof e.productName=="string"&&e.productName.trim().length?e.productName.trim():"Unknown Product",brand:typeof e.brand=="string"&&e.brand.trim().length?e.brand.trim():null,estimatedPrice:typeof e.estimatedPrice=="string"&&e.estimatedPrice.trim().length?e.estimatedPrice.trim():null,category:typeof e.category=="string"&&e.category.trim().length?e.category.trim():null,description:typeof e.description=="string"&&e.description.trim().length?e.description.trim():null}),y=async e=>{const t=m(),r=await p(t),s=u(e);try{const i=(await r.models.generateContent({model:"gemini-2.5-flash",contents:[{role:"user",parts:[{text:l},{inlineData:{mimeType:"image/jpeg",data:s}}]}],config:{responseMimeType:"application/json"}})).text||"";if(!i)throw new Error("Gemini returned an empty response.");const a=JSON.parse(i);return g(a)}catch(n){throw n?.message?.includes("API key")?n:new Error(n?.message||"Unable to identify product from the provided image.")}};export{y as identifyProduct};
