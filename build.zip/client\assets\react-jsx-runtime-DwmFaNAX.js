import{b as t}from"./react-core-DCJFkvnO.js";var r={exports:{}},e;function i(){return e||(e=1,r.exports=t()),r.exports}var u=i();export{u as j};
