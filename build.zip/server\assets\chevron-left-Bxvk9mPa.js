import{c as e}from"./createLucideIcon-Bok4r-Pq.js";const t=e("ChevronLeft",[["path",{d:"m15 18-6-6 6-6",key:"1wnfg3"}]]);export{t as C};
