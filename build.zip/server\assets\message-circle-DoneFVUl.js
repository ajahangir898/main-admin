import{c as e}from"./createLucideIcon-Bok4r-Pq.js";const c=e("MessageCircle",[["path",{d:"m3 21 1.9-5.7a8.5 8.5 0 1 1 3.8 3.8z",key:"v2veuj"}]]);export{c as M};
